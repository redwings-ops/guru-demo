module.exports = {
  testEnvironment: 'node',
  roots: ['<rootDir>']
}
